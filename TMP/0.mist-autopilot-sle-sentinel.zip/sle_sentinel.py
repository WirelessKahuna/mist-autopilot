"""
SLE Sentinel
============
Monitors all Mist SLE metrics (Wireless, Wired, WAN) across every site
in the org. Fires anomaly findings when a metric either:
  - Drops below a fixed threshold (absolute floor), OR
  - Drops more than a configured number of points from its recent baseline

Autonomy levels implemented:
  L1 — Detects SLE anomalies org-wide
  L2 — Classifies failure domain (RF / client / switch / WAN) using
        the SLE classifier breakdown returned by the Mist API
  L3 — Webhook notification hook-in point (stubbed, ready to enable)

Adding webhook notifications:
  Set WEBHOOK_URL in your .env and uncomment the _notify() call
  at the bottom of analyze(). The payload is pre-built.
"""

import asyncio
import logging
from dataclasses import dataclass

from models import ModuleOutput, Finding, Severity, SiteResult
from mist_client import MistClient
from .base import BaseModule

logger = logging.getLogger(__name__)

# ── SLE metric definitions ───────────────────────────────────────────────────

@dataclass
class SLEMetric:
    key: str            # Mist API metric key
    label: str          # Human-readable name
    scope: str          # "wireless" | "wired" | "wan"
    threshold: float    # Absolute floor — below this = anomaly
    baseline_drop: float  # Drop from baseline that triggers anomaly


METRICS: list[SLEMetric] = [
    # Wireless
    SLEMetric("wifi-coverage",        "Wi-Fi Coverage",       "wireless", threshold=80.0, baseline_drop=10.0),
    SLEMetric("wifi-capacity",        "Wi-Fi Capacity",       "wireless", threshold=80.0, baseline_drop=10.0),
    SLEMetric("roaming",              "Roaming",              "wireless", threshold=75.0, baseline_drop=10.0),
    SLEMetric("wifi-throughput",      "Wi-Fi Throughput",     "wireless", threshold=80.0, baseline_drop=10.0),
    SLEMetric("ap-availability",      "AP Availability",      "wireless", threshold=90.0, baseline_drop=5.0),
    # Wired
    SLEMetric("switch-poe",           "Switch PoE",           "wired",    threshold=90.0, baseline_drop=5.0),
    SLEMetric("switch-throughput",    "Switch Throughput",    "wired",    threshold=80.0, baseline_drop=10.0),
    # WAN
    SLEMetric("wan-availability",     "WAN Availability",     "wan",      threshold=95.0, baseline_drop=5.0),
    SLEMetric("wan-throughput",       "WAN Throughput",       "wan",      threshold=80.0, baseline_drop=10.0),
]

METRIC_MAP = {m.key: m for m in METRICS}

# Lookup: SLE metric key → likely failure domains for L2 classification
FAILURE_DOMAIN_MAP: dict[str, list[str]] = {
    "wifi-coverage":     ["RF / Coverage", "AP placement", "TX power"],
    "wifi-capacity":     ["RF / Interference", "Channel utilization", "Client density"],
    "roaming":           ["RF / Roaming", "Band steering", "BSS transition"],
    "wifi-throughput":   ["RF / Throughput", "Client capability", "Congestion"],
    "ap-availability":   ["AP health", "PoE", "Uplink connectivity"],
    "switch-poe":        ["PoE budget", "Switch hardware", "Cable/port fault"],
    "switch-throughput": ["Switch congestion", "Uplink capacity", "Port errors"],
    "wan-availability":  ["WAN link", "Gateway", "ISP"],
    "wan-throughput":    ["WAN bandwidth", "QoS policy", "ISP throttling"],
}

# SLE scope strings the Mist API accepts
SCOPE_LABELS = {
    "wireless": "Wireless",
    "wired":    "Wired",
    "wan":      "WAN",
}


# ── Helpers ──────────────────────────────────────────────────────────────────

def _extract_score(sle_data: dict, metric_key: str) -> float | None:
    """
    Pull the current SLE score for a given metric from the API response.
    Mist returns SLE data in varying shapes depending on endpoint version;
    this handles the most common structures.
    """
    if not sle_data or not isinstance(sle_data, dict):
        return None

    # Shape 1: {"results": [{"metric": "wifi-coverage", "value": 87.3, ...}]}
    results = sle_data.get("results", [])
    if isinstance(results, list):
        for entry in results:
            if isinstance(entry, dict) and entry.get("metric") == metric_key:
                val = entry.get("value") or entry.get("sle_value")
                if val is not None:
                    try:
                        return float(val)
                    except (TypeError, ValueError):
                        pass

    # Shape 2: {"metric": "wifi-coverage", "value": 87.3}
    if sle_data.get("metric") == metric_key:
        val = sle_data.get("value") or sle_data.get("sle_value")
        if val is not None:
            try:
                return float(val)
            except (TypeError, ValueError):
                pass

    # Shape 3: flat dict keyed by metric name
    val = sle_data.get(metric_key)
    if val is not None:
        try:
            return float(val) if not isinstance(val, dict) else float(val.get("value", 0))
        except (TypeError, ValueError):
            pass

    return None


def _extract_classifiers(sle_data: dict, metric_key: str) -> list[dict]:
    """
    Extract classifier breakdown for L2 failure domain classification.
    Returns list of {name, impact} dicts sorted by impact descending.
    """
    classifiers = []
    results = sle_data.get("results", [])
    if isinstance(results, list):
        for entry in results:
            if isinstance(entry, dict) and entry.get("metric") == metric_key:
                for clf in entry.get("classifiers", []):
                    name   = clf.get("classifier") or clf.get("name", "unknown")
                    impact = clf.get("impact") or clf.get("value") or 0
                    try:
                        classifiers.append({"name": name, "impact": float(impact)})
                    except (TypeError, ValueError):
                        pass
    return sorted(classifiers, key=lambda x: x["impact"], reverse=True)


def _classify_failure_domain(metric_key: str, classifiers: list[dict]) -> str:
    """
    Build an L2 failure domain string from classifier data.
    Falls back to the static domain map if no classifiers are available.
    """
    if classifiers:
        top = classifiers[:3]
        parts = [f'{c["name"]} ({c["impact"]:.0f}%)' for c in top]
        return "Top classifiers: " + ", ".join(parts)
    domains = FAILURE_DOMAIN_MAP.get(metric_key, ["Unknown"])
    return "Likely domains: " + ", ".join(domains)


def _severity_for_anomaly(score: float, threshold: float, baseline: float | None) -> Severity:
    """
    Determine finding severity based on how far the score has fallen.
    """
    gap = threshold - score  # how far below threshold
    baseline_gap = (baseline - score) if baseline is not None else 0

    if score < threshold - 20 or baseline_gap > 20:
        return Severity.critical
    if score < threshold - 10 or baseline_gap > 15:
        return Severity.warning
    return Severity.info


# ── Stub for L3 webhook (ready to enable) ───────────────────────────────────

async def _notify_webhook(payload: dict) -> None:
    """
    L3 stub — push anomaly context to a webhook endpoint.
    To enable:
      1. Set WEBHOOK_URL in your .env
      2. Uncomment the import and call below
    """
    # import httpx, os
    # url = os.getenv("WEBHOOK_URL")
    # if not url:
    #     return
    # async with httpx.AsyncClient(timeout=10) as client:
    #     await client.post(url, json=payload)
    pass


# ── Module ───────────────────────────────────────────────────────────────────

class SLESentinelModule(BaseModule):
    module_id    = "sle_sentinel"
    display_name = "SLE Sentinel"
    icon         = "📊"

    async def analyze(self, org_id: str, sites: list[dict], client: MistClient) -> ModuleOutput:

        # ── 1. Fetch SLE data for all sites in parallel ──────────────────────
        # We fetch the same endpoint three times per site with different
        # duration windows to build a baseline (7d) vs current (1d) comparison.
        async def fetch_site_sle(site_id: str, duration: str) -> dict:
            try:
                return await client.get(
                    f"/api/v1/sites/{site_id}/sle/metric",
                    params={"duration": duration},
                    use_cache=True,
                )
            except Exception as e:
                logger.warning(f"SLE fetch failed for site {site_id} ({duration}): {e}")
                return {}

        # Build fetch tasks: current window (1d) and baseline window (7d)
        current_tasks  = [fetch_site_sle(s["id"], "1d") for s in sites]
        baseline_tasks = [fetch_site_sle(s["id"], "7d") for s in sites]

        all_results = await asyncio.gather(*current_tasks, *baseline_tasks)
        current_data  = list(all_results[:len(sites)])
        baseline_data = list(all_results[len(sites):])

        # ── 2. Analyse each site ─────────────────────────────────────────────
        all_findings: list[Finding] = []
        site_results: list[SiteResult] = []
        webhook_payloads: list[dict] = []

        for site, curr_sle, base_sle in zip(sites, current_data, baseline_data):
            site_id   = site["id"]
            site_name = site.get("name", site_id)
            site_findings: list[Finding] = []

            for metric in METRICS:
                current_score  = _extract_score(curr_sle,  metric.key)
                baseline_score = _extract_score(base_sle,  metric.key)

                if current_score is None:
                    # Metric not available for this site (scope not licensed/enabled)
                    continue

                # ── L1: Anomaly Detection ────────────────────────────────────
                below_threshold = current_score < metric.threshold
                below_baseline  = (
                    baseline_score is not None
                    and (baseline_score - current_score) >= metric.baseline_drop
                )

                if not (below_threshold or below_baseline):
                    continue  # No anomaly — skip

                # ── L2: Failure Domain Classification ───────────────────────
                classifiers   = _extract_classifiers(curr_sle, metric.key)
                failure_domain = _classify_failure_domain(metric.key, classifiers)
                severity      = _severity_for_anomaly(
                    current_score, metric.threshold, baseline_score
                )

                # Build trigger description
                triggers = []
                if below_threshold:
                    triggers.append(
                        f"score {current_score:.1f} is below threshold of {metric.threshold}"
                    )
                if below_baseline:
                    drop = baseline_score - current_score
                    triggers.append(
                        f"dropped {drop:.1f} pts from 7-day baseline of {baseline_score:.1f}"
                    )

                scope_label = SCOPE_LABELS.get(metric.scope, metric.scope.title())

                finding = Finding(
                    severity=severity,
                    title=f"{site_name} — {metric.label} SLE anomaly",
                    detail=(
                        f"[{scope_label}] {metric.label}: current score {current_score:.1f}. "
                        f"{' and '.join(t.capitalize() for t in triggers)}. "
                        f"{failure_domain}."
                    ),
                    site_id=site_id,
                    site_name=site_name,
                    affected=[metric.label],
                    recommendation=_build_recommendation(metric, current_score, classifiers),
                    raw={
                        "metric":         metric.key,
                        "scope":          metric.scope,
                        "current_score":  current_score,
                        "baseline_score": baseline_score,
                        "threshold":      metric.threshold,
                        "classifiers":    classifiers,
                    },
                )

                site_findings.append(finding)
                all_findings.append(finding)

                # ── L3: Build webhook payload (ready to fire) ────────────────
                webhook_payloads.append({
                    "site_id":       site_id,
                    "site_name":     site_name,
                    "metric":        metric.key,
                    "metric_label":  metric.label,
                    "scope":         metric.scope,
                    "current_score": current_score,
                    "baseline_score": baseline_score,
                    "severity":      severity.value,
                    "failure_domain": failure_domain,
                    "recommendation": finding.recommendation,
                })

            site_score = self.score_from_findings(site_findings)
            site_results.append(SiteResult(
                site_id=site_id,
                site_name=site_name,
                score=site_score,
                severity=self.severity_from_score(site_score),
                findings=site_findings,
            ))

        # ── 3. L3 webhook dispatch (stubbed — uncomment to enable) ──────────
        # for payload in webhook_payloads:
        #     await _notify_webhook(payload)

        # ── 4. Score and summarise ───────────────────────────────────────────
        score    = self.score_from_findings(all_findings)
        severity = self.severity_from_score(score)

        critical_count = sum(1 for f in all_findings if f.severity == Severity.critical)
        warning_count  = sum(1 for f in all_findings if f.severity == Severity.warning)
        anomaly_sites  = len({f.site_id for f in all_findings if f.site_id})

        scope_counts: dict[str, int] = {}
        for f in all_findings:
            scope = f.raw.get("scope", "unknown") if f.raw else "unknown"
            scope_counts[scope] = scope_counts.get(scope, 0) + 1

        if not all_findings:
            summary = f"All SLE metrics healthy across {len(sites)} sites."
        else:
            parts = []
            if critical_count: parts.append(f"{critical_count} critical")
            if warning_count:  parts.append(f"{warning_count} warnings")
            scope_str = ", ".join(
                f"{SCOPE_LABELS.get(k, k)}: {v}" for k, v in scope_counts.items()
            )
            summary = (
                f"{anomaly_sites} sites with SLE anomalies — "
                + ", ".join(parts)
                + f". ({scope_str})"
            )

        return ModuleOutput(
            module_id=self.module_id,
            display_name=self.display_name,
            icon=self.icon,
            score=score,
            severity=severity,
            summary=summary,
            findings=all_findings,
            sites=site_results,
            status="ok",
        )


def _build_recommendation(metric: SLEMetric, score: float, classifiers: list[dict]) -> str:
    """
    Build a specific, actionable recommendation based on the metric type
    and top classifiers returned by Mist.
    """
    top_classifier = classifiers[0]["name"].lower() if classifiers else ""

    recommendations: dict[str, str] = {
        "wifi-coverage": (
            "Check for coverage gaps using the Mist location map. "
            "Review AP TX power settings and consider additional APs in weak-signal areas. "
            "Verify RRM is enabled and performing auto-adjustments."
        ),
        "wifi-capacity": (
            "Review channel utilization per AP. Check for co-channel interference (CCI) "
            "on 2.4 GHz. Consider enabling 6 GHz if APs and clients support Wi-Fi 6E. "
            "Review band steering thresholds to push clients to less congested bands."
        ),
        "roaming": (
            "Check BSS transition (802.11v) and fast BSS transition (802.11r) settings. "
            "Review sticky client thresholds. Ensure AP TX power is not too high, "
            "which can cause clients to hold onto distant APs."
        ),
        "wifi-throughput": (
            "Review minimum data rates — disable legacy rates (1, 2, 5.5 Mbps) on 5/6 GHz. "
            "Check for RF interference sources. Verify WMM QoS is enabled."
        ),
        "ap-availability": (
            "Check AP uptime in Mist dashboard. Review PoE budget on connected switches. "
            "Inspect uplink port status. Consider enabling AP auto-upgrade "
            "to resolve firmware-related crash loops."
        ),
        "switch-poe": (
            "Review PoE budget utilisation per switch. Check for overloaded PoE ports. "
            "Verify PoE+ (802.3at) or PoE++ (802.3bt) is being used for high-draw devices."
        ),
        "switch-throughput": (
            "Review switch port utilisation and error counters. "
            "Check for duplex mismatches and CRC errors. "
            "Consider uplink capacity if inter-VLAN traffic is high."
        ),
        "wan-availability": (
            "Check WAN link status and gateway health in Mist. "
            "Review SD-WAN failover policies. Verify SLA probe destinations are reachable. "
            "Contact ISP if physical link is degraded."
        ),
        "wan-throughput": (
            "Review WAN bandwidth utilisation. Check for QoS policy misconfiguration. "
            "Verify traffic shaping policies are not throttling legitimate traffic. "
            "Consider increasing WAN capacity if sustained utilisation exceeds 80%."
        ),
    }

    base_rec = recommendations.get(
        metric.key,
        f"Review {metric.label} SLE classifiers in the Mist dashboard for root cause details."
    )

    # Append classifier-specific context if available
    if top_classifier and "interference" in top_classifier:
        base_rec += " Top classifier suggests RF interference — run a spectrum scan."
    elif top_classifier and "auth" in top_classifier:
        base_rec += " Top classifier suggests authentication failures — review RADIUS logs."
    elif top_classifier and "dhcp" in top_classifier:
        base_rec += " Top classifier suggests DHCP issues — check DHCP server capacity and lease times."
    elif top_classifier and "dns" in top_classifier:
        base_rec += " Top classifier suggests DNS resolution failures — verify DNS server reachability."

    return base_rec
